'use strict';

module.exports = {
    /**
     * When editing your questions pay attention to your punctuation. Make sure you use question marks or periods.
     * Make sure the first answer is the correct one. Set at least ANSWER_COUNT answers, any extras will be shuffled in.
     */
    QUESTIONS_EN_US: [
        {
            'What is the minimum number of deaths for Dothraki wedding to be considered a proper party?': [
                '3',
                '2',
                '1',
                '4',
                '5',
            ],
        },
        {
            'According to Littlefinger, who owns the dagger used in the attack on Bran Stark?': [
                'Tyrion',
                'Joffrey',
                'Jaime',
                'Littlefinger',
            ],
        },
        {
            'Which direwolf is sacrificed at Cersei\'s command after Joffrey is bitten?': [
                'Lady',
                'Nymeria',
                'Shaggy Dog',
                'Summer',
            ],
        },
        {
            'Littlefinger lost a duel to Brandon Stark. Why were they fighting?': [
                'To win Catelyn Tully\'s affection',
                'To settle a lost bet',
                'To practice new techniques',
                'To win a torunament in the Riverlands',
            ],
        },
        {
            'How many men are still in the Night\'s Watch?': [
                'less than a thousand',
                '2,000',
                '7,000',
                '3,000',
            ],
        },
        {
            'Which of these is not an aspect of The Seven?': [
                'Child',
                'Crone',
                'Smith',
                'Maiden',
            ],
        },
        {
            'Which member of the Small Council refuses to approve the assassination of Daenerys?': [
                'Ned',
                'Littlefinger',
                'Robert',
                'Varys',
            ],
        },
        {
            'Where does Jon Snow take his vows for the Night\'s Watch?': [
                'The godswood',
                'The courtyard',
                'The dining hall',
                'Before the Wall',
            ],
        },
        {
            'True or False, Ned confessed to treason before his execution.': [
                'TRUE',
                'FALSE',
            ],
        },
        {
            'Who does Twin name Hand of the King in his place while he fights?': [
                'Tyrion',
                'Kevan',
                'Pycelle',
                'Cersei',
            ],
        },
    ],
};
